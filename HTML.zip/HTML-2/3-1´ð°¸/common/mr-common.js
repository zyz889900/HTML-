function closeCode(){
	var codeArea=document.getElementById("codeArea");
    codeArea.className="container containerHome";
}

function showCode(){
    var codeArea=document.getElementById("codeArea");
    codeArea.className="container containerHome viewerOpen";
}