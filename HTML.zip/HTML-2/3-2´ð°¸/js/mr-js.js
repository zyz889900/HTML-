const mSpan = document.getElementById('model').getElementsByTagName('span');
const cSpan = document.getElementById('color').getElementsByTagName('span');
const rSpan = document.getElementById('rom').getElementsByTagName('span');
const bSpan = document.getElementById('banben').getElementsByTagName('span');
const aSpan = document.getElementsByTagName('span');
const oModel = document.getElementById('model');
const oRom = document.getElementById('rom');
const oPrice = document.getElementById('price');
mSpan[0].className ='on'; 
cSpan[0].className ='on'; 
rSpan[0].className ='on'; 
bSpan[0].className ='on'; 
for (let i=0; i<aSpan.length; i++) {
	aSpan[i].onclick = function () {
		const siblings = this.parentNode.children;
		for (let j = 0; j < siblings.length; j++) {
			siblings[j].className = '';
		}
		this.className = 'on';
		if (this.parentNode === oModel || this.parentNode === oRom) {
			price();
		}
	};
}
function price() {
	let p1 = 0;
	let p2 = 0;
	for (var i = 0; i < mSpan.length; i++) {
		if (mSpan[i].className === 'on') {
			p1 = i ? 6088 : 5288;
			break;
		}
	}
	for (var i = 0; i < rSpan.length; i++) {
		if (rSpan[i].className === 'on') {
			switch (i) {
				case 0:
					p2 = 0;
					break;
				case 1:
					p2 = 800;
					break;
				case 2:
					p2 = 1600;
					break;
			}
		}
	}
	oPrice.innerHTML = p1 + p2;
}