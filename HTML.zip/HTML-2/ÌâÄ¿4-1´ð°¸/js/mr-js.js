// JavaScript Document
function showPic(i) {
	const dpics = document.getElementById('mr-pic' + i);
	dpics.style.display = 'block';
}
function hidPic(i) {
	const dpics = document.getElementById('mr-pic' + i);
	dpics.style.display = 'none';
}
function bordr(c) {
	const bord = document.getElementsByClassName('mr-messtxt2')[c];
	bord.style.border = "1px dashed #f00"
}
function clearBordr(c) {
	const bord = document.getElementsByClassName('mr-messtxt2')[c];
	bord.style.border = "none"
}
function sel() {
	const checkboxs = document.getElementsByTagName('input');
	for (let i = 0; i < checkboxs.length; i++) {
		if (checkboxs[i].type === 'checkbox') {
			checkboxs[i].checked = document.getElementsByName('a')[0].checked
		}
	}
}
function comp(z) {
	const price = [1199.00, 1580.00, 3578.00];
	const num = document.getElementById('num' + z).value;
	const mone = document.getElementById('all' + z);
	mone.innerHTML = price[z] * num;
}
function amoney() {
	let anum = 0;
	let aprice = 0;
	for (let i = 0; i < 3; i++) {
		const num = parseInt(document.getElementById('num' + i).value);
		const price = parseInt(document.getElementById('all' + i).innerHTML);
		anum += num;
		aprice += price;
	}
	document.getElementById('allnum').innerHTML = anum;
	document.getElementById('allprice').innerHTML = aprice;
}